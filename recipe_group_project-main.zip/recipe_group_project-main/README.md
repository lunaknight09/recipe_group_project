# recipe_group_project Version 5.3

SP24Recipe  
Recipe database for SDEV 265 group project

## Team

* Project Manager: Nathan Hopkins
* Lead Developer: David Cruz
* Designer/ NoteTaker: Hanifah Amin
* Designer/ QA Tester: Chabha Arkoub
  
## How to use

Download cryptography via pip

~~~ PIP
pip install cryptography
~~~

After downloading cryptography, run the RecipeApp.py file.
