from .StartScreen import StartScreen
from .CreateDataBaseScreen import InitDatabaseScreen
# from .LoadDatabaseScreen import LoadDatabaseScreen  # deprecated
from .RecipeIndexScreen import RecipeIndex
from .ViewRecipeScreen import ViewRecipe
# from .CreateUserScreen import CreateUser  # deprecated
from .CreateAdminScreen import CreateAdmin
from .LoginScreen import Login
# from .UserIndexScreen import UserIndex  # deprecated
from .MainMenuScreen import MainMenu